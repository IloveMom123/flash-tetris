# Ruffle Example

This repository provides an example/demo of how to use Ruffle on your own website to emulate Flash content. Ruffle is an open-source Flash Player emulator that allows you to continue running Flash content in modern browsers.

Video Explanation: https://www.youtube.com/watch?v=TJXMGNxex24&t=81s
